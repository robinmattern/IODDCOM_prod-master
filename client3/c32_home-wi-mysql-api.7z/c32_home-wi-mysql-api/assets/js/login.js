


document.cookie = "UserID = ; expires=Thu, 18 Dec 2013 12:00:00 UTC; path=/;"
document.cookie = "UserID = ; path=/"
//alert(`Member ID Set to 90\n ${document.cookie}`)
